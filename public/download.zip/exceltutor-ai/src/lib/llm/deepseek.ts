// ============================================================
// ExcelTutor AI — DeepSeek LLM Integration
// ============================================================

import type { SimStep } from '@/types';
import { APP_CONFIG } from '@/config/constants';
import { getTemplateById } from '@/config/excel-templates';

/**
 * System prompt untuk DeepSeek.
 * Output harus valid JSON array of SimStep.
 */
function buildSystemPrompt(templateId?: string): string {
  const template = templateId ? getTemplateById(templateId) : null;

  const templateContext = template
    ? `\nData spreadsheet yang tersedia:\n` +
      `Kolom: ${template.columns.map((c) => `${c.id}: ${c.name}`).join(', ')}\n` +
      `Data awal:\n${Object.entries(template.initialData)
        .map(([cell, val]) => `  ${cell}: ${val}`)
        .join('\n')}\n` +
      `Petunjuk: ${template.systemHint}`
    : '\nBuat data sendiri yang relevan dengan topik tutorial.';

  return `You are an Excel tutorial script generator in Bahasa Indonesia.
Buat tutorial yang SANGAT DETAIL dan PANJANG untuk pemula total.
BAYANGKAN kamu sedang mengajar teman yang tidak tahu apa-apa tentang Excel.
Setiap langkah harus dijelaskan dengan sangat jelas.

${templateContext}

Return ONLY valid JSON array. Setiap step WAJIB memiliki semua field berikut:

{
  "stepNumber": number,
  "title": string, (judul yang deskriptif, e.g. "Klik cell F2 sebagai tempat hasil VLOOKUP")
  "narration": string, (2-3 kalimat dalam SATU BARIS, bahasa Indonesia santai dan sangat detail.
    Jelaskan APA yang dilakukan, MENGAPA dilakukan, dan apa yang akan terjadi.
    Contoh: "Sekarang kita akan memilih cell F2 untuk menampilkan hasil pencarian harga. Cell ini masih kosong, tapi nanti akan berisi harga produk yang kita cari. Perhatikan formula bar di atas, nanti rumus VLOOKUP akan muncul di sana.")
  "cellActions": [
    {
      "type": "highlight" | "type" | "select" | "moveCursor",
      "targetCell": string, (e.g. "B3")
      "value": string, (UNTUK type action: isi dengan teks/nilai yang diketik)
      "highlightColor": "yellow" | "blue" | "green" | "orange"
    }
  ],
  "formulaBar": {
    "cellName": string,
    "formula": string, (isi dengan formula lengkap yang tampil di formula bar)
    "isActive": boolean (true saat cell sedang diedit/diketik)
  },
  "tooltip": {
    "targetCell": string,
    "text": string (penjelasan tentang cell ini, kenapa cell ini penting)
  }
}

PENTING:
- BUAT 10-15 STEP yang DETAIL (jangan 5-6 step doang)
- Setiap step yang melibatkan typing WAJIB menyertakan formulaBar dengan formula yang sedang diketik
- narrative harus menjelaskan APA, MENGAPA, dan BAGAIMANA
- cellActions harus URUT: pertama select cell, lalu type, lalu highlight hasil
- GUNakan data dari template jika tersedia
- tooltip harus informatif untuk pemula
- Untuk fungsi seperti VLOOKUP/IF/dll, TUNJUKKAN formula lengkap di formulaBar
- BUAT STEPS YANG PANJANG DAN DETAIL, minimal 8 step

Return ONLY valid JSON array. No explanation.`;
}

/**
 * Panggil DeepSeek API untuk generate tutorial steps.
 */
export async function generateSteps(
  prompt: string,
  templateId?: string
): Promise<SimStep[]> {
  const systemPrompt = buildSystemPrompt(templateId);

  const response = await fetch(`${APP_CONFIG.llm.apiBaseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`,
    },
    body: JSON.stringify({
      model: APP_CONFIG.llm.defaultModel,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Topik: ${prompt}\n\nGenerate langkah-langkah tutorial Excel untuk topik di atas.` },
      ],
      max_tokens: APP_CONFIG.llm.maxTokens,
      temperature: APP_CONFIG.llm.temperature,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text().catch(() => '');
    throw new Error(
      `DeepSeek API error: ${response.status} ${response.statusText}${errorBody ? ` - ${errorBody}` : ''}`
    );
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;

  if (!content) {
    throw new Error('DeepSeek returned empty response');
  }

  // Parse JSON dari response (mungkin ada markdown code block)
  const jsonStr = extractJson(content);
  const parsed = JSON.parse(jsonStr);

  if (!Array.isArray(parsed)) {
    throw new Error('DeepSeek did not return an array');
  }

  // Validate & normalize
  const steps: SimStep[] = parsed.map((step: any, i: number) => ({
    stepNumber: step.stepNumber || i + 1,
    title: step.title || `Step ${i + 1}`,
    narration: step.narration || '',
    duration: step.duration || 3000,
    cellActions: (step.cellActions || []).map((action: any) => ({
      type: action.type || 'select',
      targetCell: action.targetCell || 'A1',
      value: action.value,
      highlightColor: action.highlightColor,
      delay: action.delay || 0,
    })),
    formulaBar: {
      cellName: step.formulaBar?.cellName || '',
      formula: step.formulaBar?.formula || '',
      isActive: step.formulaBar?.isActive || false,
    },
    tooltip: step.tooltip
      ? {
          targetCell: step.tooltip.targetCell || '',
          text: step.tooltip.text || '',
        }
      : undefined,
  }));

  return steps;
}

/**
 * Extract JSON string from LLM response (strip markdown code blocks).
 */
function extractJson(text: string): string {
  // Coba parse langsung dulu
  try {
    JSON.parse(text);
    return text;
  } catch {
    // Cari di dalam ```json ... ``` block
    const jsonBlockMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (jsonBlockMatch) {
      return jsonBlockMatch[1].trim();
    }
    // Cari array JSON ([...]) di text
    const arrayMatch = text.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      return arrayMatch[0];
    }
    throw new Error('No valid JSON found in LLM response');
  }
}
