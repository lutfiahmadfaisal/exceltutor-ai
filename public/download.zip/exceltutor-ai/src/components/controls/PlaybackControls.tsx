// ============================================================
// ExcelTutor AI — Playback Controls
// ============================================================

'use client';

import { useCallback, useRef, useEffect } from 'react';
import { useExcelStore } from '@/store/excel-store';
import { setupMediaRecorder } from '@/lib/video-export/client-export';

interface PlaybackControlsProps {
  canvasRef?: React.RefObject<HTMLCanvasElement | null>;
}

export default function PlaybackControls({ canvasRef }: PlaybackControlsProps) {
  const recorderRef = useRef<MediaRecorder | null>(null);

  const steps = useExcelStore((s) => s.steps);
  const currentStepIndex = useExcelStore((s) => s.currentStepIndex);
  const isPlaying = useExcelStore((s) => s.isPlaying);
  const speed = useExcelStore((s) => s.speed);
  const status = useExcelStore((s) => s.status);
  const isRecording = useExcelStore((s) => s.isRecording);
  const videoUrl = useExcelStore((s) => s.videoUrl);
  const progress = useExcelStore((s) => s.progress());
  const totalSteps = useExcelStore((s) => s.totalSteps());

  const togglePlay = useExcelStore((s) => s.setIsPlaying);
  const prevStep = useExcelStore((s) => s.prevStep);
  const nextStep = useExcelStore((s) => s.nextStep);
  const setSpeed = useExcelStore((s) => s.setSpeed);
  const setTheme = useExcelStore((s) => s.setTheme);
  const setIsRecording = useExcelStore((s) => s.setIsRecording);
  const setExportProgress = useExcelStore((s) => s.setExportProgress);
  const setVideoUrl = useExcelStore((s) => s.setVideoUrl);
  const setStatus = useExcelStore((s) => s.setStatus);

  const hasSteps = steps.length > 0;

  /** Mulai/stop recording video */
  const handleToggleRecording = useCallback(() => {
    if (isRecording) {
      // Stop recording
      recorderRef.current?.stop();
      setIsRecording(false);
      setExportProgress(100);
      return;
    }

    if (!canvasRef?.current) return;

    const recorder = setupMediaRecorder(canvasRef.current, {
      fps: 30,
      onStop: async (blob) => {
        // Kirim ke server untuk convert WebM → MP4
        try {
          setStatus('exporting');
          setExportProgress(50);

          const form = new FormData();
          form.append('video', blob, 'tutorial.webm');

          const res = await fetch('/api/convert-mp4', {
            method: 'POST',
            body: form,
          });

          if (!res.ok) throw new Error('Conversion failed');

          const data = await res.json();
          setVideoUrl(data.mp4Url, data.filename);
          setExportProgress(100);
          setStatus('ready');
        } catch (err) {
          // Fallback: download WebM langsung
          const url = URL.createObjectURL(blob);
          setVideoUrl(url, 'tutorial.webm');
          setExportProgress(100);
          setStatus('ready');
        }
      },
      onError: (err) => {
        console.error('MediaRecorder error:', err);
        setIsRecording(false);
        setStatus('error');
      },
    });

    if (recorder) {
      recorderRef.current = recorder;
      recorder.start(1000); // chunk setiap 1 detik
      setIsRecording(true);
      setExportProgress(0);
    }
  }, [isRecording, canvasRef, setIsRecording, setExportProgress, setVideoUrl, setStatus]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (recorderRef.current && recorderRef.current.state === 'recording') {
        recorderRef.current.stop();
      }
    };
  }, []);

  const btnBase: React.CSSProperties = {
    padding: '8px 16px',
    border: '1px solid #DADCE0',
    borderRadius: 6,
    background: '#FFFFFF',
    cursor: hasSteps ? 'pointer' : 'not-allowed',
    fontSize: 13,
    fontWeight: 500,
    color: hasSteps ? '#202124' : '#9AA0A6',
    fontFamily: "'Segoe UI', sans-serif",
    transition: 'all 0.15s',
  };

  const activeBtn: React.CSSProperties = {
    ...btnBase,
    background: '#217346',
    color: '#FFFFFF',
    border: '1px solid #217346',
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        padding: 16,
        background: '#F8F9FA',
        borderRadius: 8,
        border: '1px solid #DADCE0',
      }}
    >
      {/* Progress bar */}
      {hasSteps && (
        <div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: 12,
              color: '#5F6368',
              marginBottom: 4,
              fontFamily: "'Segoe UI', sans-serif",
            }}
          >
            <span>
              Step {currentStepIndex + 1} / {totalSteps}
            </span>
            <span>{progress}%</span>
          </div>
          <div
            style={{
              width: '100%',
              height: 6,
              background: '#E8EAED',
              borderRadius: 3,
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                width: `${progress}%`,
                height: '100%',
                background: '#217346',
                transition: 'width 0.3s ease',
              }}
            />
          </div>
        </div>
      )}

      {/* Main controls */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        {/* Previous */}
        <button
          style={btnBase}
          disabled={!hasSteps}
          onClick={prevStep}
          title="Step sebelumnya"
        >
          ⏮ Prev
        </button>

        {/* Play/Pause */}
        <button
          style={hasSteps ? { ...activeBtn, minWidth: 90 } : { ...btnBase, minWidth: 90 }}
          disabled={!hasSteps}
          onClick={() => togglePlay(!isPlaying)}
        >
          {isPlaying ? '⏸ Pause' : '▶ Play'}
        </button>

        {/* Next */}
        <button
          style={btnBase}
          disabled={!hasSteps}
          onClick={nextStep}
          title="Step berikutnya"
        >
          Next ⏭
        </button>

        {/* Spacer */}
        <div style={{ flex: 1 }} />

        {/* Speed selector */}
        <select
          value={speed}
          onChange={(e) => setSpeed(e.target.value as any)}
          style={{
            ...btnBase,
            cursor: 'pointer',
            minWidth: 80,
          }}
        >
          <option value="slow">🐢 Lambat</option>
          <option value="normal">🐇 Normal</option>
          <option value="fast">⚡ Cepat</option>
        </select>

        {/* Theme selector */}
        <select
          onChange={(e) => setTheme(e.target.value as any)}
          style={{
            ...btnBase,
            cursor: 'pointer',
            minWidth: 80,
          }}
        >
          <option value="classic">Excel Classic</option>
          <option value="dark">Dark Mode</option>
          <option value="modern">Modern</option>
        </select>
      </div>

      {/* Recording & Export */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <button
          style={isRecording ? activeBtn : btnBase}
          disabled={!hasSteps || (status !== 'ready' && status !== 'generated')}
          onClick={handleToggleRecording}
        >
          {isRecording ? '⏹ Stop Recording' : '🔴 Record Video'}
        </button>

        {/* Video download */}
        {videoUrl && (
          <a
            href={videoUrl}
            download
            style={{
              ...btnBase,
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              background: '#1A73E8',
              color: '#FFFFFF',
              border: '1px solid #1A73E8',
            }}
          >
            ⬇ Download MP4
          </a>
        )}

        {/* Status info */}
        <span
          style={{
            fontSize: 12,
            color: '#5F6368',
            fontFamily: "'Segoe UI', sans-serif",
            marginLeft: 'auto',
          }}
        >
          {status === 'recording' && '🎬 Merekam...'}
          {status === 'exporting' && '⏳ Mengkonversi...'}
          {status === 'ready' && '✅ Siap'}
          {status === 'idle' && 'Masukkan prompt'}
        </span>
      </div>
    </div>
  );
}
